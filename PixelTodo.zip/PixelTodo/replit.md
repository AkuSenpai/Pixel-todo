# Task Management Application

## Overview

This is a full-stack task management application built with React, Express, and PostgreSQL. The application features a pixel-art inspired design with a retro aesthetic and provides comprehensive task and project management capabilities. Users can create, organize, and track tasks across different projects with features like priority levels, due dates, and completion tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom pixel-art theme and CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with structured error handling and logging middleware
- **Development**: Hot module reloading with Vite integration for seamless development experience

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: Two main entities - projects and tasks with proper relationships
- **Migrations**: Drizzle Kit for database schema management
- **Development Storage**: In-memory storage implementation for development/testing
- **Connection**: Neon Database serverless PostgreSQL for production

### Database Schema Design
- **Projects Table**: Stores project information with customizable colors and icons
- **Tasks Table**: Comprehensive task management with priorities, due dates, completion tracking, and project associations
- **Relationships**: Foreign key relationship between tasks and projects
- **Data Types**: Uses PostgreSQL-specific types including JSONB for flexible note storage

### Authentication and Authorization
- Currently implements a basic session-based structure with connect-pg-simple for PostgreSQL session storage
- Ready for future authentication implementation

### External Dependencies
- **Database**: Neon Database (@neondatabase/serverless) for serverless PostgreSQL
- **ORM**: Drizzle ORM with PostgreSQL dialect for database operations
- **UI Framework**: Comprehensive Radix UI component suite for accessible components
- **Validation**: Zod for runtime type validation and schema definition
- **Styling**: Tailwind CSS with extensive Radix UI integration
- **Development**: Replit-specific plugins for enhanced development experience
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions
- **Date Handling**: date-fns for date manipulation and formatting
- **Icons**: Lucide React for consistent iconography