#!/usr/bin/env node

const { spawn } = require('child_process');
const path = require('path');

function runCommand(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    console.log(`Running: ${command} ${args.join(' ')}`);
    const child = spawn(command, args, {
      stdio: 'inherit',
      shell: process.platform === 'win32',
      ...options
    });

    child.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`Command failed with exit code ${code}`));
      }
    });

    child.on('error', reject);
  });
}

async function buildElectronApp() {
  try {
    console.log('🏗️  Building the web application...');
    await runCommand('npm', ['run', 'build']);
    
    console.log('📦 Packaging with electron-builder...');
    await runCommand('npx', ['electron-builder', '--config', 'electron-builder.json', '--win', '--x64']);
    
    console.log('✅ Electron app built successfully!');
    console.log('📁 Check the dist-electron directory for your .exe file');
  } catch (error) {
    console.error('❌ Build failed:', error.message);
    process.exit(1);
  }
}

buildElectronApp();