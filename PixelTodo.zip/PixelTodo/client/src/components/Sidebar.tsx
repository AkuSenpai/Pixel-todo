import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  List, 
  CalendarDays, 
  Check, 
  AlertTriangle, 
  Plus,
  Briefcase,
  Home,
  Heart
} from "lucide-react";
import { useStats } from "@/hooks/use-tasks";
import { useProjects } from "@/hooks/use-projects";
import { AddProjectModal } from "./AddProjectModal";

interface SidebarProps {
  activeFilter: string;
  onFilterChange: (filter: string) => void;
  activeProject: string | null;
  onProjectChange: (projectId: string | null) => void;
}

const projectIcons: Record<string, React.ReactNode> = {
  "fas fa-briefcase": <Briefcase className="w-4 h-4" />,
  "fas fa-home": <Home className="w-4 h-4" />,
  "fas fa-heart": <Heart className="w-4 h-4" />,
};

const projectColors: Record<string, string> = {
  "#00bcd4": "border-l-cyan-500",
  "#8bc34a": "border-l-lime-500", 
  "#e91e63": "border-l-pink-500",
};

export function Sidebar({ activeFilter, onFilterChange, activeProject, onProjectChange }: SidebarProps) {
  const [showAddProject, setShowAddProject] = useState(false);
  const { data: stats } = useStats();
  const { data: projects } = useProjects();

  const progressPercentage = stats ? (stats.completed / Math.max(stats.total, 1)) * 100 : 0;

  return (
    <>
      <aside className="w-80 bg-card border-r-4 border-border p-6 overflow-y-auto">
        <div className="space-y-6">
          
          {/* Stats Overview */}
          <div className="bg-muted border-2 border-border p-4">
            <h2 className="text-lg font-bold mb-4 text-foreground font-pixel">STATS</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-accent font-pixel" data-testid="stats-completed">
                  {stats?.completed || 0}
                </div>
                <div className="text-xs text-muted-foreground font-pixel">DONE</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-pixel-yellow font-pixel" data-testid="stats-pending">
                  {stats?.pending || 0}
                </div>
                <div className="text-xs text-muted-foreground font-pixel">TODO</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-destructive font-pixel" data-testid="stats-overdue">
                  {stats?.overdue || 0}
                </div>
                <div className="text-xs text-muted-foreground font-pixel">LATE</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary font-pixel" data-testid="stats-total">
                  {stats?.total || 0}
                </div>
                <div className="text-xs text-muted-foreground font-pixel">TOTAL</div>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="bg-muted border-2 border-border p-4">
            <h3 className="text-sm font-bold mb-2 text-foreground font-pixel">PROGRESS</h3>
            <div className="pixel-progress h-4 border-2 border-border bg-secondary relative overflow-hidden">
              <div 
                className="absolute top-0 left-0 h-full bg-accent transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
                data-testid="progress-bar"
              />
            </div>
            <div className="text-xs text-muted-foreground mt-1 font-pixel" data-testid="progress-text">
              {Math.round(progressPercentage)}% COMPLETE
            </div>
          </div>

          {/* Filters */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold text-foreground font-pixel">FILTERS</h2>
            
            {/* Quick Filters */}
            <div className="space-y-2">
              <Button
                onClick={() => {
                  onFilterChange('all');
                  onProjectChange(null);
                }}
                className={`pixel-button w-full text-left px-3 py-2 font-bold font-pixel ${
                  activeFilter === 'all' && !activeProject
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-card text-card-foreground hover:bg-secondary'
                }`}
                data-testid="filter-all"
              >
                <List className="w-4 h-4 mr-2" />
                ALL TASKS ({stats?.total || 0})
              </Button>
              <Button
                onClick={() => {
                  onFilterChange('today');
                  onProjectChange(null);
                }}
                className={`pixel-button w-full text-left px-3 py-2 font-pixel ${
                  activeFilter === 'today' && !activeProject
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-card text-card-foreground hover:bg-secondary'
                }`}
                data-testid="filter-today"
              >
                <CalendarDays className="w-4 h-4 mr-2" />
                TODAY (0)
              </Button>
              <Button
                onClick={() => {
                  onFilterChange('completed');
                  onProjectChange(null);
                }}
                className={`pixel-button w-full text-left px-3 py-2 font-pixel ${
                  activeFilter === 'completed' && !activeProject
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-card text-card-foreground hover:bg-secondary'
                }`}
                data-testid="filter-completed"
              >
                <Check className="w-4 h-4 mr-2" />
                DONE ({stats?.completed || 0})
              </Button>
              <Button
                onClick={() => {
                  onFilterChange('overdue');
                  onProjectChange(null);
                }}
                className={`pixel-button w-full text-left px-3 py-2 font-pixel ${
                  activeFilter === 'overdue' && !activeProject
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-card text-card-foreground hover:bg-secondary'
                }`}
                data-testid="filter-overdue"
              >
                <AlertTriangle className="w-4 h-4 mr-2" />
                OVERDUE ({stats?.overdue || 0})
              </Button>
            </div>
          </div>

          {/* Projects/Categories */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground font-pixel">PROJECTS</h2>
              <Button
                onClick={() => setShowAddProject(true)}
                className="pixel-button bg-secondary text-secondary-foreground px-2 py-1 text-xs"
                data-testid="button-add-project"
              >
                <Plus className="w-3 h-3" />
              </Button>
            </div>
            
            <div className="space-y-2">
              {projects?.map((project) => (
                <Button
                  key={project.id}
                  onClick={() => {
                    onProjectChange(project.id);
                    onFilterChange('all');
                  }}
                  className={`pixel-button w-full text-left px-3 py-2 ${
                    activeProject === project.id
                      ? 'bg-accent text-accent-foreground'
                      : 'bg-card text-card-foreground hover:bg-secondary'
                  } ${projectColors[project.color] || 'border-l-4 border-l-gray-500'}`}
                  data-testid={`project-${project.id}`}
                >
                  <div className="flex items-center justify-between">
                    <span className="flex items-center font-pixel">
                      {projectIcons[project.icon] || <Home className="w-4 h-4" />}
                      <span className="ml-2">{project.name}</span>
                    </span>
                    <span className="text-xs px-2 py-1" style={{ backgroundColor: project.color, color: '#000' }}>
                      0
                    </span>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Keyboard Shortcuts */}
          <div className="bg-muted border-2 border-border p-4 text-xs">
            <h3 className="font-bold mb-2 text-foreground font-pixel">SHORTCUTS</h3>
            <div className="space-y-1 text-muted-foreground font-pixel">
              <div><kbd className="bg-secondary px-1">N</kbd> New Task</div>
              <div><kbd className="bg-secondary px-1">/</kbd> Search</div>
              <div><kbd className="bg-secondary px-1">T</kbd> Toggle Theme</div>
              <div><kbd className="bg-secondary px-1">ESC</kbd> Close Modal</div>
            </div>
          </div>
        </div>
      </aside>

      <AddProjectModal
        open={showAddProject}
        onOpenChange={setShowAddProject}
      />
    </>
  );
}
