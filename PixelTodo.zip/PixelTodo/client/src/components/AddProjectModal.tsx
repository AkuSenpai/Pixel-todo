import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Plus } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateProject } from "@/hooks/use-projects";
import { useToast } from "@/hooks/use-toast";

const projectFormSchema = z.object({
  name: z.string().min(1, "Project name is required"),
  color: z.string().min(1, "Please select a color"),
  icon: z.string().min(1, "Please select an icon"),
});

type ProjectFormData = z.infer<typeof projectFormSchema>;

interface AddProjectModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const colorOptions = [
  { value: '#00bcd4', label: 'CYAN', class: 'bg-cyan-500' },
  { value: '#8bc34a', label: 'LIME', class: 'bg-lime-500' },
  { value: '#e91e63', label: 'PINK', class: 'bg-pink-500' },
  { value: '#ff9800', label: 'ORANGE', class: 'bg-orange-500' },
  { value: '#9c27b0', label: 'PURPLE', class: 'bg-purple-500' },
  { value: '#f44336', label: 'RED', class: 'bg-red-500' },
];

const iconOptions = [
  { value: 'fas fa-briefcase', label: 'BRIEFCASE' },
  { value: 'fas fa-home', label: 'HOME' },
  { value: 'fas fa-heart', label: 'HEART' },
  { value: 'fas fa-graduation-cap', label: 'EDUCATION' },
  { value: 'fas fa-shopping-cart', label: 'SHOPPING' },
  { value: 'fas fa-car', label: 'TRAVEL' },
  { value: 'fas fa-gamepad', label: 'HOBBY' },
  { value: 'fas fa-dumbbell', label: 'FITNESS' },
];

export function AddProjectModal({ open, onOpenChange }: AddProjectModalProps) {
  const createProject = useCreateProject();
  const { toast } = useToast();

  const form = useForm<ProjectFormData>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: {
      name: "",
      color: "",
      icon: "",
    },
  });

  const handleSubmit = async (data: ProjectFormData) => {
    try {
      await createProject.mutateAsync({
        name: data.name.toUpperCase(),
        color: data.color,
        icon: data.icon,
      });
      
      toast({
        title: "Success",
        description: "Project created successfully",
      });
      
      form.reset();
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create project",
        variant: "destructive",
      });
    }
  };

  const handleClose = () => {
    form.reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-4 border-border p-6 w-full max-w-md font-pixel">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl font-bold text-foreground font-pixel">
              CREATE PROJECT
            </DialogTitle>
            <Button
              onClick={handleClose}
              className="pixel-button bg-destructive text-destructive-foreground px-3 py-2"
              data-testid="button-close-project-modal"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          <div>
            <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">PROJECT NAME *</Label>
            <Input
              {...form.register('name')}
              className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel focus:border-ring focus:outline-none"
              placeholder="Enter project name..."
              data-testid="input-project-name"
            />
            {form.formState.errors.name && (
              <p className="text-destructive text-sm mt-1 font-pixel">
                {form.formState.errors.name.message}
              </p>
            )}
          </div>
          
          <div>
            <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">COLOR *</Label>
            <Select value={form.watch('color')} onValueChange={(value) => form.setValue('color', value)}>
              <SelectTrigger className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel focus:border-ring focus:outline-none" data-testid="select-project-color">
                <SelectValue placeholder="Select color..." />
              </SelectTrigger>
              <SelectContent>
                {colorOptions.map((color) => (
                  <SelectItem key={color.value} value={color.value}>
                    <div className="flex items-center space-x-2">
                      <div className={`w-4 h-4 ${color.class} border border-border`} />
                      <span>{color.label}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.color && (
              <p className="text-destructive text-sm mt-1 font-pixel">
                {form.formState.errors.color.message}
              </p>
            )}
          </div>
          
          <div>
            <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">ICON *</Label>
            <Select value={form.watch('icon')} onValueChange={(value) => form.setValue('icon', value)}>
              <SelectTrigger className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel focus:border-ring focus:outline-none" data-testid="select-project-icon">
                <SelectValue placeholder="Select icon..." />
              </SelectTrigger>
              <SelectContent>
                {iconOptions.map((icon) => (
                  <SelectItem key={icon.value} value={icon.value}>
                    {icon.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.formState.errors.icon && (
              <p className="text-destructive text-sm mt-1 font-pixel">
                {form.formState.errors.icon.message}
              </p>
            )}
          </div>
          
          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              onClick={handleClose}
              className="pixel-button bg-secondary text-secondary-foreground px-6 py-3 font-pixel"
              data-testid="button-cancel-project"
            >
              CANCEL
            </Button>
            <Button
              type="submit"
              disabled={createProject.isPending}
              className="pixel-button bg-primary text-primary-foreground px-6 py-3 font-bold font-pixel"
              data-testid="button-submit-project"
            >
              <Plus className="w-4 h-4 mr-2" />
              CREATE PROJECT
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
