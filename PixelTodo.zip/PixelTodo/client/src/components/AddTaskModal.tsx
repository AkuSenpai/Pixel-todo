import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { X, Plus } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateTask, useUpdateTask } from "@/hooks/use-tasks";
import { useProjects } from "@/hooks/use-projects";
import { useToast } from "@/hooks/use-toast";
import { type TaskWithProject } from "@shared/schema";

const taskFormSchema = z.object({
  title: z.string().min(1, "Task title is required"),
  description: z.string().optional(),
  priority: z.enum(['low', 'medium', 'high']).default('medium'),
  projectId: z.string().optional(),
  dueDate: z.string().optional(),
  reminder: z.boolean().default(false),
});

type TaskFormData = z.infer<typeof taskFormSchema>;

interface AddTaskModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editTask?: TaskWithProject | null;
}

export function AddTaskModal({ open, onOpenChange, editTask }: AddTaskModalProps) {
  const createTask = useCreateTask();
  const updateTask = useUpdateTask();
  const { data: projects } = useProjects();
  const { toast } = useToast();

  const form = useForm<TaskFormData>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: "",
      description: "",
      priority: 'medium',
      projectId: "none",
      dueDate: "",
      reminder: false,
    },
  });

  // Reset form when editTask changes
  useEffect(() => {
    if (editTask) {
      form.reset({
        title: editTask.title,
        description: editTask.description || "",
        priority: editTask.priority as 'low' | 'medium' | 'high',
        projectId: editTask.projectId || "none",
        dueDate: editTask.dueDate ? new Date(editTask.dueDate).toISOString().split('T')[0] : "",
        reminder: false,
      });
    } else {
      form.reset({
        title: "",
        description: "",
        priority: 'medium',
        projectId: "none",
        dueDate: "",
        reminder: false,
      });
    }
  }, [editTask, form]);

  const handleSubmit = async (data: TaskFormData) => {
    try {
      const taskData = {
        title: data.title,
        description: data.description || "",
        priority: data.priority,
        projectId: data.projectId === "none" ? null : data.projectId,
        dueDate: data.dueDate ? new Date(data.dueDate) : null,
        completed: false,
        notes: [],
        position: "0",
      };

      if (editTask) {
        await updateTask.mutateAsync({ id: editTask.id, updates: taskData });
        toast({
          title: "Success",
          description: "Task updated successfully",
        });
      } else {
        await createTask.mutateAsync(taskData);
        toast({
          title: "Success", 
          description: "Task created successfully",
        });
      }
      
      form.reset();
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: editTask ? "Failed to update task" : "Failed to create task",
        variant: "destructive",
      });
    }
  };

  const handleClose = () => {
    form.reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-4 border-border p-6 w-full max-w-2xl font-pixel" onClick={(e) => e.stopPropagation()}>
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl font-bold text-foreground font-pixel">
              {editTask ? 'EDIT TASK' : 'CREATE NEW TASK'}
            </DialogTitle>
            <Button
              onClick={handleClose}
              className="pixel-button bg-destructive text-destructive-foreground px-3 py-2"
              data-testid="button-close-modal"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          <div>
            <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">TASK TITLE *</Label>
            <Input
              {...form.register('title')}
              className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel focus:border-ring focus:outline-none"
              placeholder="Enter task title..."
              data-testid="input-task-title"
            />
            {form.formState.errors.title && (
              <p className="text-destructive text-sm mt-1 font-pixel">
                {form.formState.errors.title.message}
              </p>
            )}
          </div>
          
          <div>
            <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">DESCRIPTION</Label>
            <Textarea
              {...form.register('description')}
              className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel h-24 resize-none focus:border-ring focus:outline-none"
              placeholder="Add task description..."
              data-testid="textarea-task-description"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">PRIORITY</Label>
              <Select value={form.watch('priority')} onValueChange={(value) => form.setValue('priority', value as 'low' | 'medium' | 'high')}>
                <SelectTrigger className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel focus:border-ring focus:outline-none" data-testid="select-priority">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">LOW</SelectItem>
                  <SelectItem value="medium">MEDIUM</SelectItem>
                  <SelectItem value="high">HIGH</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">PROJECT</Label>
              <Select value={form.watch('projectId')} onValueChange={(value) => form.setValue('projectId', value)}>
                <SelectTrigger className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel focus:border-ring focus:outline-none" data-testid="select-project">
                  <SelectValue placeholder="Select project..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">NO PROJECT</SelectItem>
                  {projects?.map((project) => (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="block text-sm font-bold text-foreground mb-2 font-pixel">DUE DATE</Label>
              <Input
                {...form.register('dueDate')}
                type="date"
                className="w-full bg-input border-2 border-border px-4 py-3 text-foreground font-pixel focus:border-ring focus:outline-none"
                data-testid="input-due-date"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Checkbox
              checked={form.watch('reminder')}
              onCheckedChange={(checked) => form.setValue('reminder', !!checked)}
              className="w-4 h-4 border-2 border-border bg-input"
              data-testid="checkbox-reminder"
            />
            <Label className="text-sm text-foreground font-pixel">SET REMINDER NOTIFICATION</Label>
          </div>
          
          <div className="flex justify-end space-x-4">
            <Button
              type="button"
              onClick={handleClose}
              className="pixel-button bg-secondary text-secondary-foreground px-6 py-3 font-pixel"
              data-testid="button-cancel"
            >
              CANCEL
            </Button>
            <Button
              type="submit"
              disabled={createTask.isPending || updateTask.isPending}
              className="pixel-button bg-primary text-primary-foreground px-6 py-3 font-bold font-pixel"
              data-testid="button-submit-task"
            >
              <Plus className="w-4 h-4 mr-2" />
              {editTask ? 'UPDATE TASK' : 'CREATE TASK'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
