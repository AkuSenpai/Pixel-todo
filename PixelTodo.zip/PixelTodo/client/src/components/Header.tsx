import { useState } from "react";
import { Search, Moon, Sun, Plus, ListTodo } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTheme } from "./ThemeProvider";

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onNewTask: () => void;
}

export function Header({ searchQuery, onSearchChange, onNewTask }: HeaderProps) {
  const { theme, toggleTheme } = useTheme();
  
  return (
    <header className="bg-card border-b-4 border-border p-4 sticky top-0 z-50">
      <div className="flex items-center justify-between max-w-7xl mx-auto">
        <div className="flex items-center space-x-4">
          <div className="w-8 h-8 bg-primary border-2 border-primary-foreground flex items-center justify-center">
            <ListTodo className="w-4 h-4 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold text-foreground font-pixel">
            PIXEL<span className="text-accent">TASK</span>
          </h1>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Search Bar */}
          <div className="relative">
            <Input
              type="text"
              placeholder="SEARCH TASKS..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="bg-input border-2 border-border px-4 py-2 w-64 text-foreground font-pixel text-sm focus:border-ring focus:outline-none"
              data-testid="input-search"
            />
            <Search className="w-4 h-4 absolute right-3 top-3 text-muted-foreground" />
          </div>
          
          {/* Theme Toggle */}
          <Button
            onClick={toggleTheme}
            className="pixel-button bg-secondary text-secondary-foreground px-4 py-2 hover:bg-accent hover:text-accent-foreground"
            data-testid="button-toggle-theme"
          >
            {theme === 'light' ? (
              <Moon className="w-4 h-4 mr-2" />
            ) : (
              <Sun className="w-4 h-4 mr-2" />
            )}
            <span className="font-pixel">{theme === 'light' ? 'DARK' : 'LIGHT'}</span>
          </Button>
          
          {/* Add Task Button */}
          <Button
            onClick={onNewTask}
            className="pixel-button bg-primary text-primary-foreground px-6 py-2 hover:bg-pixel-cyan hover:text-background font-bold font-pixel"
            data-testid="button-new-task"
          >
            <Plus className="w-4 h-4 mr-2" />
            NEW TASK
          </Button>
        </div>
      </div>
    </header>
  );
}
