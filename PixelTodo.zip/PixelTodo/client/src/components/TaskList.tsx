import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { List, Grid3X3, Check, Trash2 } from "lucide-react";
import { TaskItem } from "./TaskItem";
import { type TaskWithProject } from "@shared/schema";
import { useTasks } from "@/hooks/use-tasks";

interface TaskListProps {
  searchQuery: string;
  activeFilter: string;
  activeProject: string | null;
  onEditTask: (task: TaskWithProject) => void;
}

export function TaskList({ searchQuery, activeFilter, activeProject, onEditTask }: TaskListProps) {
  const [sortBy, setSortBy] = useState('date');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);

  // Build filters for the query
  const filters: any = {};
  
  if (searchQuery) filters.search = searchQuery;
  if (activeProject) filters.project = activeProject;
  
  switch (activeFilter) {
    case 'completed':
      filters.completed = true;
      break;
    case 'overdue':
      // Will need to handle this in the component since it requires date comparison
      break;
    case 'today':
      // Will need to handle this in the component since it requires date comparison
      break;
  }

  const { data: tasks = [], isLoading } = useTasks(filters);

  // Apply additional client-side filtering
  let filteredTasks = tasks;
  
  if (activeFilter === 'overdue') {
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    filteredTasks = tasks.filter(task => 
      !task.completed && 
      task.dueDate && 
      new Date(task.dueDate) < today
    );
  } else if (activeFilter === 'today') {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    today.setHours(0, 0, 0, 0);
    tomorrow.setHours(0, 0, 0, 0);
    
    filteredTasks = tasks.filter(task => 
      task.dueDate && 
      new Date(task.dueDate) >= today && 
      new Date(task.dueDate) < tomorrow
    );
  }

  // Apply sorting
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    switch (sortBy) {
      case 'priority':
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return (priorityOrder[b.priority as keyof typeof priorityOrder] || 0) - 
               (priorityOrder[a.priority as keyof typeof priorityOrder] || 0);
      case 'project':
        return (a.project?.name || '').localeCompare(b.project?.name || '');
      case 'status':
        return Number(a.completed) - Number(b.completed);
      case 'date':
      default:
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  const getFilterTitle = () => {
    if (activeProject) {
      const project = filteredTasks[0]?.project;
      return project ? project.name : 'PROJECT TASKS';
    }
    
    switch (activeFilter) {
      case 'completed': return 'COMPLETED TASKS';
      case 'overdue': return 'OVERDUE TASKS';
      case 'today': return 'TODAY\'S TASKS';
      default: return 'ALL TASKS';
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6 flex items-center justify-center">
        <div className="text-center">
          <div className="pixel-glow w-16 h-16 bg-primary mx-auto mb-4"></div>
          <p className="font-pixel text-muted-foreground">LOADING TASKS...</p>
        </div>
      </div>
    );
  }

  return (
    <main className="flex-1 p-6 overflow-y-auto">
      {/* Toolbar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-foreground font-pixel" data-testid="task-list-title">
            {getFilterTitle()}
          </h2>
          <div className="flex space-x-2">
            {/* Sort Options */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="bg-input border-2 border-border px-3 py-2 text-foreground font-pixel text-sm focus:border-ring focus:outline-none w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">SORT BY DATE</SelectItem>
                <SelectItem value="priority">SORT BY PRIORITY</SelectItem>
                <SelectItem value="project">SORT BY PROJECT</SelectItem>
                <SelectItem value="status">SORT BY STATUS</SelectItem>
              </SelectContent>
            </Select>
            
            {/* View Toggle */}
            <div className="flex border-2 border-border">
              <Button
                onClick={() => setViewMode('list')}
                className={`pixel-button px-3 py-2 border-0 ${
                  viewMode === 'list' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-card text-card-foreground hover:bg-secondary'
                }`}
                data-testid="view-list"
              >
                <List className="w-4 h-4" />
              </Button>
              <Button
                onClick={() => setViewMode('grid')}
                className={`pixel-button px-3 py-2 border-0 ${
                  viewMode === 'grid' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-card text-card-foreground hover:bg-secondary'
                }`}
                data-testid="view-grid"
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Bulk Actions */}
        {selectedTasks.length > 0 && (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground font-pixel">
              {selectedTasks.length} SELECTED
            </span>
            <Button className="pixel-button bg-secondary text-secondary-foreground px-3 py-2 text-sm font-pixel">
              <Check className="w-4 h-4 mr-1" />
              COMPLETE
            </Button>
            <Button className="pixel-button bg-destructive text-destructive-foreground px-3 py-2 text-sm font-pixel">
              <Trash2 className="w-4 h-4 mr-1" />
              DELETE
            </Button>
          </div>
        )}
      </div>

      {/* Task List */}
      <div className={`space-y-4 ${viewMode === 'grid' ? 'grid grid-cols-1 lg:grid-cols-2 gap-4' : ''}`}>
        {sortedTasks.length === 0 ? (
          <div className="text-center py-16">
            <List className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-xl font-bold text-foreground mb-2 font-pixel">NO TASKS FOUND</h3>
            <p className="text-muted-foreground font-pixel">
              {searchQuery 
                ? 'No tasks match your search criteria' 
                : 'Create your first task to get started'
              }
            </p>
          </div>
        ) : (
          sortedTasks.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              onEdit={onEditTask}
            />
          ))
        )}
      </div>

      {/* Load More Button (if needed for pagination) */}
      {sortedTasks.length > 0 && sortedTasks.length >= 10 && (
        <div className="text-center py-8">
          <Button className="pixel-button bg-secondary text-secondary-foreground px-6 py-3 font-pixel">
            LOAD MORE
          </Button>
        </div>
      )}
    </main>
  );
}
