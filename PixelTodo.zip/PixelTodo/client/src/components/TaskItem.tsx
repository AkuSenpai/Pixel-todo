import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar,
  Clock,
  User,
  StickyNote,
  Edit,
  Trash2,
  CheckCircle
} from "lucide-react";
import { type TaskWithProject } from "@shared/schema";
import { useToggleTask, useDeleteTask } from "@/hooks/use-tasks";
import { useToast } from "@/hooks/use-toast";
import { format, isToday, isPast } from "date-fns";

interface TaskItemProps {
  task: TaskWithProject;
  onEdit: (task: TaskWithProject) => void;
}

const priorityColors = {
  high: 'border-l-destructive',
  medium: 'border-l-pixel-yellow', 
  low: 'border-l-muted-foreground',
};

const priorityBadgeColors = {
  high: 'bg-destructive text-destructive-foreground',
  medium: 'bg-pixel-yellow text-background',
  low: 'bg-muted-foreground text-background',
};

const projectColors: Record<string, string> = {
  "#00bcd4": "bg-pixel-cyan text-background",
  "#8bc34a": "bg-pixel-lime text-background", 
  "#e91e63": "bg-pixel-magenta text-background",
};

export function TaskItem({ task, onEdit }: TaskItemProps) {
  const [showNotes, setShowNotes] = useState(false);
  const toggleTask = useToggleTask();
  const deleteTask = useDeleteTask();
  const { toast } = useToast();

  const handleToggle = async () => {
    try {
      await toggleTask.mutateAsync(task.id);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async () => {
    try {
      await deleteTask.mutateAsync(task.id);
      toast({
        title: "Success",
        description: "Task deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error", 
        description: "Failed to delete task",
        variant: "destructive",
      });
    }
  };

  const formatDueDate = (dueDate: Date) => {
    if (isToday(dueDate)) return 'TODAY';
    if (isPast(dueDate)) return `OVERDUE: ${format(dueDate, 'MMM d')}`;
    return `DUE: ${format(dueDate, 'MMM d')}`;
  };

  const getDueDateColor = (dueDate: Date) => {
    if (isPast(dueDate) && !task.completed) return 'text-destructive';
    if (isToday(dueDate)) return 'text-pixel-orange';
    return 'text-muted-foreground';
  };

  return (
    <div 
      className={`pixel-task-item bg-card p-4 ${priorityColors[task.priority as keyof typeof priorityColors]} ${
        task.completed ? 'opacity-60' : ''
      }`}
      data-testid={`task-${task.id}`}
    >
      <div className="flex items-start space-x-4">
        <Checkbox
          checked={task.completed}
          onCheckedChange={handleToggle}
          className="w-5 h-5 border-2 border-border bg-input mt-1"
          data-testid={`checkbox-task-${task.id}`}
        />
        
        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <h3 className={`text-lg font-bold text-foreground font-pixel ${
              task.completed ? 'line-through' : ''
            }`}>
              {task.title}
            </h3>
            <div className="flex items-center space-x-2">
              <Badge className={`${priorityBadgeColors[task.priority as keyof typeof priorityBadgeColors]} px-2 py-1 text-xs font-bold font-pixel`}>
                {task.priority.toUpperCase()}
              </Badge>
              {task.project && (
                <Badge className={`${
                  projectColors[task.project.color] || 'bg-gray-500 text-background'
                } px-2 py-1 text-xs font-pixel`}>
                  {task.project.name}
                </Badge>
              )}
              <Button
                onClick={() => onEdit(task)}
                className="pixel-button bg-secondary text-secondary-foreground px-2 py-1 text-xs"
                data-testid={`button-edit-${task.id}`}
              >
                <Edit className="w-3 h-3" />
              </Button>
              <Button
                onClick={handleDelete}
                className="pixel-button bg-destructive text-destructive-foreground px-2 py-1 text-xs"
                data-testid={`button-delete-${task.id}`}
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </div>
          
          {task.description && (
            <p className="text-sm text-muted-foreground mb-3 font-pixel">
              {task.description}
            </p>
          )}
          
          <div className="flex items-center justify-between text-xs text-muted-foreground font-pixel">
            <div className="flex items-center space-x-4">
              {task.dueDate && (
                <span className={getDueDateColor(new Date(task.dueDate))}>
                  <Calendar className="w-3 h-3 mr-1 inline" />
                  {formatDueDate(new Date(task.dueDate))}
                </span>
              )}
              {task.completedAt ? (
                <span className="text-accent">
                  <CheckCircle className="w-3 h-3 mr-1 inline" />
                  COMPLETED {format(new Date(task.completedAt), 'MMM d')}
                </span>
              ) : (
                <span>
                  <Clock className="w-3 h-3 mr-1 inline" />
                  CREATED: {format(new Date(task.createdAt), 'MMM d')}
                </span>
              )}
            </div>
            {task.notes && Array.isArray(task.notes) && task.notes.length > 0 && (
              <Button
                onClick={() => setShowNotes(!showNotes)}
                className="text-accent hover:text-pixel-cyan text-xs font-pixel"
                variant="ghost"
                size="sm"
                data-testid={`button-notes-${task.id}`}
              >
                <StickyNote className="w-3 h-3 mr-1" />
                NOTES
              </Button>
            )}
          </div>
          
          {/* Expandable Notes Section */}
          {showNotes && task.notes && Array.isArray(task.notes) && task.notes.length > 0 && (
            <div className="mt-3 bg-muted border-2 border-border p-3" data-testid={`notes-${task.id}`}>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-bold text-sm font-pixel">TASK NOTES</h4>
                <Button className="pixel-button bg-primary text-primary-foreground px-2 py-1 text-xs font-pixel">
                  <StickyNote className="w-3 h-3 mr-1" />
                  ADD NOTE
                </Button>
              </div>
              <div className="space-y-2 text-sm">
                {(task.notes as Array<{timestamp?: string, content?: string}>).map((note, index: number) => (
                  <div key={index} className="bg-card p-2 border-2 border-border">
                    <div className="text-xs text-muted-foreground mb-1 font-pixel">
                      {note.timestamp ? format(new Date(note.timestamp), 'h:mm a - MMM d') : 'No timestamp'}
                    </div>
                    <p className="font-pixel">{note.content || 'No content'}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
