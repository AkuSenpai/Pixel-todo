import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type TaskWithProject, type InsertTask } from "@shared/schema";

export function useTasks(filters?: {
  project?: string;
  completed?: boolean;
  priority?: string;
  search?: string;
}) {
  const queryParams = new URLSearchParams();
  
  if (filters?.project) queryParams.set('project', filters.project);
  if (filters?.completed !== undefined) queryParams.set('completed', String(filters.completed));
  if (filters?.priority) queryParams.set('priority', filters.priority);
  if (filters?.search) queryParams.set('search', filters.search);
  
  const queryString = queryParams.toString();
  const endpoint = `/api/tasks${queryString ? `?${queryString}` : ''}`;

  return useQuery<TaskWithProject[]>({
    queryKey: ['/api/tasks', filters],
    queryFn: async () => {
      const response = await fetch(endpoint);
      if (!response.ok) {
        throw new Error('Failed to fetch tasks');
      }
      return response.json();
    },
  });
}

export function useCreateTask() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (task: InsertTask) => {
      const response = await apiRequest('POST', '/api/tasks', task);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
  });
}

export function useUpdateTask() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<InsertTask> }) => {
      const response = await apiRequest('PATCH', `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
  });
}

export function useToggleTask() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest('PATCH', `/api/tasks/${id}/toggle`, {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
  });
}

export function useDeleteTask() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
  });
}

export function useStats() {
  return useQuery<{ total: number; completed: number; pending: number; overdue: number }>({
    queryKey: ['/api/stats'],
  });
}
