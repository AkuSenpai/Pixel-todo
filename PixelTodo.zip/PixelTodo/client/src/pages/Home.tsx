import { useState, useEffect } from "react";
import { Header } from "@/components/Header";
import { Sidebar } from "@/components/Sidebar";
import { TaskList } from "@/components/TaskList";
import { AddTaskModal } from "@/components/AddTaskModal";
import { type TaskWithProject } from "@shared/schema";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");
  const [activeProject, setActiveProject] = useState<string | null>(null);
  const [showAddTask, setShowAddTask] = useState(false);
  const [editTask, setEditTask] = useState<TaskWithProject | null>(null);

  const handleNewTask = () => {
    setEditTask(null);
    setShowAddTask(true);
  };

  const handleEditTask = (task: TaskWithProject) => {
    setEditTask(task);
    setShowAddTask(true);
  };

  const handleCloseTaskModal = (open: boolean) => {
    setShowAddTask(open);
    if (!open) {
      setEditTask(null);
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Only activate shortcuts if no input is focused
      const activeElement = document.activeElement;
      if (activeElement?.tagName === 'INPUT' || 
          activeElement?.tagName === 'TEXTAREA' || 
          activeElement?.tagName === 'SELECT') {
        return;
      }

      switch(e.key.toLowerCase()) {
        case 'n':
          e.preventDefault();
          handleNewTask();
          break;
        case '/':
          e.preventDefault();
          const searchInput = document.querySelector('[data-testid="input-search"]') as HTMLInputElement;
          searchInput?.focus();
          break;
        case 't':
          e.preventDefault();
          const themeButton = document.querySelector('[data-testid="button-toggle-theme"]') as HTMLButtonElement;
          themeButton?.click();
          break;
        case 'escape':
          setShowAddTask(false);
          setEditTask(null);
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onNewTask={handleNewTask}
      />
      
      <div className="flex min-h-screen">
        <Sidebar
          activeFilter={activeFilter}
          onFilterChange={setActiveFilter}
          activeProject={activeProject}
          onProjectChange={setActiveProject}
        />
        
        <TaskList
          searchQuery={searchQuery}
          activeFilter={activeFilter}
          activeProject={activeProject}
          onEditTask={handleEditTask}
        />
      </div>

      <AddTaskModal
        open={showAddTask}
        onOpenChange={handleCloseTaskModal}
        editTask={editTask}
      />
    </div>
  );
}
