#!/usr/bin/env node

const { spawn } = require('child_process');
const path = require('path');

function runCommand(command, args, options = {}) {
  return spawn(command, args, {
    stdio: 'inherit',
    shell: process.platform === 'win32',
    ...options
  });
}

async function runElectronDev() {
  console.log('🚀 Starting development server and Electron app...');
  
  // Start the dev server
  const devServer = runCommand('npm', ['run', 'dev']);
  
  // Wait a bit for the server to start, then start electron
  setTimeout(() => {
    console.log('⚡ Starting Electron...');
    runCommand('npx', ['electron', '.']);
  }, 3000);

  // Handle cleanup
  process.on('SIGINT', () => {
    console.log('\n🛑 Stopping development server...');
    devServer.kill();
    process.exit(0);
  });
}

runElectronDev();