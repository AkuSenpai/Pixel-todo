# PixelTask Electron Desktop App Setup

This guide will help you build and run the PixelTask todo application as a Windows .exe desktop app.

## 📋 Prerequisites

- Node.js (v16 or higher)
- Windows machine (for building Windows .exe)
- Git

## 🛠️ Setup Instructions

### 1. Fix package.json Dependencies

Since the current setup has electron packages in `dependencies`, you need to move them to `devDependencies`. Update your `package.json`:

```json
{
  "name": "pixeltask",
  "version": "1.0.0",
  "description": "PixelTask - A pixel art styled todo application",
  "author": "Your Name <your.email@example.com>",
  "main": "electron/main.js",
  "type": "module",
  "license": "MIT",
  "scripts": {
    "dev": "NODE_ENV=development tsx server/index.ts",
    "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
    "start": "NODE_ENV=production node dist/index.js",
    "check": "tsc",
    "db:push": "drizzle-kit push",
    "electron": "npm run build && electron .",
    "electron-dev": "node run-electron-dev.js",
    "electron-pack": "node build-electron.js",
    "dist": "npm run build && electron-builder --config electron-builder.json"
  }
}
```

**Important Changes:**
- Move `electron` and `electron-builder` from `dependencies` to `devDependencies`
- Add `description` and `author` fields
- Add `main` field pointing to `electron/main.js`
- Add electron-related scripts

### 2. Install Dependencies

```bash
npm install
```

Make sure electron and electron-builder are in devDependencies:

```bash
npm install --save-dev electron electron-builder
```

## 🚀 Running the Application

### Development Mode

To run the app in development mode (with hot reload):

```bash
# Option 1: Using the helper script
node run-electron-dev.js

# Option 2: Manual (run in separate terminals)
npm run dev
# Wait for server to start, then in another terminal:
npx electron .
```

### Production Mode

To run the built app:

```bash
npm run electron
```

## 📦 Building the .exe File

### Quick Build

Use the provided build script:

```bash
node build-electron.js
```

### Manual Build

```bash
# 1. Build the web application
npm run build

# 2. Package with electron-builder
npx electron-builder --config electron-builder.json --win --x64
```

### Build Output

After successful build, you'll find:
- **Installer**: `dist-electron/PixelTask Setup 1.0.0.exe` (NSIS installer)
- **Portable**: `dist-electron/win-unpacked/PixelTask.exe` (portable executable)

## 🎯 One-Click Executable

The build process creates two types of executables:

1. **Installer** (`PixelTask Setup 1.0.0.exe`):
   - Users run this once to install the app
   - Creates desktop shortcut and start menu entry
   - Can be uninstalled through Windows settings

2. **Portable** (`dist-electron/win-unpacked/PixelTask.exe`):
   - Single executable file
   - No installation required
   - Can be run directly by double-clicking

## 📁 Project Structure

```
├── electron/
│   └── main.js              # Electron main process
├── electron-builder.json    # Build configuration
├── build-electron.js        # Build helper script
├── run-electron-dev.js      # Development helper script
├── client/                  # React frontend
├── server/                  # Express backend
└── dist/                    # Built files (created after npm run build)
```

## ⚙️ Configuration

### Electron Builder Configuration

The `electron-builder.json` file contains:
- Windows-specific build settings
- Icon configuration
- NSIS installer options
- Output directory settings

### Customization Options

You can customize the build by editing `electron-builder.json`:

- **App Name**: Change `productName`
- **App ID**: Change `appId`
- **Icons**: Add icon files (`.ico` for Windows, `.png` for Linux, `.icns` for macOS)
- **Installer Options**: Modify `nsis` settings

## 🔧 Troubleshooting

### Common Issues

1. **"electron is not allowed in dependencies"**
   - Move electron packages to devDependencies

2. **"description is missed"**
   - Add description field to package.json

3. **"author is missed"**
   - Add author field to package.json

4. **Build fails on non-Windows platform**
   - Windows .exe can only be built on Windows
   - For cross-platform builds, see electron-builder documentation

### Development Issues

1. **Server not starting**
   - Ensure the build was successful (`npm run build`)
   - Check that `dist/index.js` exists

2. **Electron window shows blank page**
   - Wait longer for server to start (increase timeout in main.js)
   - Check console for server errors

## 📚 Additional Resources

- [Electron Documentation](https://www.electronjs.org/docs)
- [Electron Builder Documentation](https://www.electron.build/)
- [Node.js Documentation](https://nodejs.org/docs/)

## 🎉 Success!

Once built successfully, you can distribute the `PixelTask Setup 1.0.0.exe` file to users. They simply need to:
1. Download the .exe file
2. Double-click to install
3. Launch PixelTask from desktop or start menu

The app runs completely offline and includes both the frontend and backend server.