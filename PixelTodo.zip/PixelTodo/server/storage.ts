import { type Task, type Project, type InsertTask, type InsertProject, type TaskWithProject } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;

  // Tasks
  getTasks(): Promise<TaskWithProject[]>;
  getTask(id: string): Promise<TaskWithProject | undefined>;
  getTasksByProject(projectId: string): Promise<TaskWithProject[]>;
  createTask(task: InsertTask): Promise<TaskWithProject>;
  updateTask(id: string, updates: Partial<InsertTask>): Promise<TaskWithProject | undefined>;
  deleteTask(id: string): Promise<boolean>;
  toggleTaskComplete(id: string): Promise<TaskWithProject | undefined>;
}

export class MemStorage implements IStorage {
  private projects: Map<string, Project>;
  private tasks: Map<string, Task>;

  constructor() {
    this.projects = new Map();
    this.tasks = new Map();
    
    // Initialize default projects
    this.initializeDefaults();
  }

  private initializeDefaults() {
    const defaultProjects: Project[] = [
      {
        id: "work",
        name: "WORK",
        color: "#00bcd4",
        icon: "fas fa-briefcase",
        createdAt: new Date(),
      },
      {
        id: "personal",
        name: "PERSONAL", 
        color: "#8bc34a",
        icon: "fas fa-home",
        createdAt: new Date(),
      },
      {
        id: "health",
        name: "HEALTH",
        color: "#e91e63",
        icon: "fas fa-heart",
        createdAt: new Date(),
      },
    ];

    defaultProjects.forEach(project => {
      this.projects.set(project.id, project);
    });
  }

  // Projects
  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = {
      id,
      name: insertProject.name,
      color: insertProject.color || "#00bcd4",
      icon: insertProject.icon || "fas fa-folder",
      createdAt: new Date(),
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject = { ...project, ...updates };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }

  // Tasks
  async getTasks(): Promise<TaskWithProject[]> {
    const tasks = Array.from(this.tasks.values()).sort((a, b) => {
      // Sort by position, then by creation date
      const posA = parseFloat(a.position || "0");
      const posB = parseFloat(b.position || "0");
      if (posA !== posB) return posA - posB;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    return tasks.map(task => ({
      ...task,
      project: task.projectId ? this.projects.get(task.projectId) : undefined,
    }));
  }

  async getTask(id: string): Promise<TaskWithProject | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    return {
      ...task,
      project: task.projectId ? this.projects.get(task.projectId) : undefined,
    };
  }

  async getTasksByProject(projectId: string): Promise<TaskWithProject[]> {
    const tasks = Array.from(this.tasks.values())
      .filter(task => task.projectId === projectId)
      .sort((a, b) => {
        const posA = parseFloat(a.position || "0");
        const posB = parseFloat(b.position || "0");
        if (posA !== posB) return posA - posB;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

    return tasks.map(task => ({
      ...task,
      project: this.projects.get(projectId),
    }));
  }

  async createTask(insertTask: InsertTask): Promise<TaskWithProject> {
    const id = randomUUID();
    const task: Task = {
      id,
      title: insertTask.title,
      description: insertTask.description || null,
      completed: insertTask.completed || false,
      priority: insertTask.priority || "medium",
      projectId: insertTask.projectId || null,
      dueDate: insertTask.dueDate || null,
      notes: insertTask.notes || [],
      position: insertTask.position || "0",
      createdAt: new Date(),
      completedAt: null,
    };
    this.tasks.set(id, task);

    return {
      ...task,
      project: task.projectId ? this.projects.get(task.projectId) : undefined,
    };
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<TaskWithProject | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const updatedTask = { ...task, ...updates };
    this.tasks.set(id, updatedTask);

    return {
      ...updatedTask,
      project: updatedTask.projectId ? this.projects.get(updatedTask.projectId) : undefined,
    };
  }

  async deleteTask(id: string): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async toggleTaskComplete(id: string): Promise<TaskWithProject | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const updatedTask = {
      ...task,
      completed: !task.completed,
      completedAt: !task.completed ? new Date() : null,
    };
    this.tasks.set(id, updatedTask);

    return {
      ...updatedTask,
      project: updatedTask.projectId ? this.projects.get(updatedTask.projectId) : undefined,
    };
  }
}

export const storage = new MemStorage();
